from enum import Enum, auto

class CellType(Enum):
    CODE = auto()
    MARKDOWN = auto()
